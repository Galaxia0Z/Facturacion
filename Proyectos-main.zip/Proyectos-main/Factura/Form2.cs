﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Factura
{
    public partial class Form2 : Factura.Form1
    {
        public Form2()
        {
            InitializeComponent();
        }
    }
}
